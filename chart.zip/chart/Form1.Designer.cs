﻿namespace chart
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.chrtSpline = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chrtPie = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chrtBarChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSales = new System.Windows.Forms.Label();
            this.la = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.lblAverageperweek = new System.Windows.Forms.Label();
            this.lblPorfit = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblPercent = new System.Windows.Forms.Label();
            this.lblDailySales = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblText = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.chrtSpline)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chrtPie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chrtBarChart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // chrtSpline
            // 
            chartArea1.Name = "ChartArea1";
            this.chrtSpline.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chrtSpline.Legends.Add(legend1);
            this.chrtSpline.Location = new System.Drawing.Point(371, 86);
            this.chrtSpline.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chrtSpline.Name = "chrtSpline";
            this.chrtSpline.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Berry;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series2.Legend = "Legend1";
            series2.Name = "Series2";
            this.chrtSpline.Series.Add(series1);
            this.chrtSpline.Series.Add(series2);
            this.chrtSpline.Size = new System.Drawing.Size(663, 265);
            this.chrtSpline.TabIndex = 357;
            this.chrtSpline.Text = "chart1";
            // 
            // chrtPie
            // 
            chartArea2.Name = "ChartArea1";
            this.chrtPie.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chrtPie.Legends.Add(legend2);
            this.chrtPie.Location = new System.Drawing.Point(1011, 357);
            this.chrtPie.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chrtPie.Name = "chrtPie";
            this.chrtPie.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Berry;
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut;
            series3.Font = new System.Drawing.Font("Century Gothic", 8F);
            series3.LabelForeColor = System.Drawing.Color.Transparent;
            series3.Legend = "Legend1";
            series3.MarkerBorderWidth = 0;
            series3.Name = "Series1";
            this.chrtPie.Series.Add(series3);
            this.chrtPie.Size = new System.Drawing.Size(364, 251);
            this.chrtPie.TabIndex = 0;
            this.chrtPie.Text = "chart1";
            // 
            // chrtBarChart
            // 
            chartArea3.Name = "ChartArea1";
            this.chrtBarChart.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.chrtBarChart.Legends.Add(legend3);
            this.chrtBarChart.Location = new System.Drawing.Point(371, 358);
            this.chrtBarChart.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chrtBarChart.Name = "chrtBarChart";
            this.chrtBarChart.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Berry;
            series4.ChartArea = "ChartArea1";
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            series5.ChartArea = "ChartArea1";
            series5.Legend = "Legend1";
            series5.Name = "Series2";
            this.chrtBarChart.Series.Add(series4);
            this.chrtBarChart.Series.Add(series5);
            this.chrtBarChart.Size = new System.Drawing.Size(632, 251);
            this.chrtBarChart.TabIndex = 0;
            this.chrtBarChart.Text = "chart1";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(16, 318);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(347, 292);
            this.dataGridView1.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumOrchid;
            this.panel1.Controls.Add(this.lblSales);
            this.panel1.Controls.Add(this.la);
            this.panel1.Location = new System.Drawing.Point(16, 86);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(347, 107);
            this.panel1.TabIndex = 2;
            // 
            // lblSales
            // 
            this.lblSales.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold);
            this.lblSales.ForeColor = System.Drawing.Color.White;
            this.lblSales.Location = new System.Drawing.Point(15, 44);
            this.lblSales.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSales.Name = "lblSales";
            this.lblSales.Size = new System.Drawing.Size(103, 34);
            this.lblSales.TabIndex = 1;
            this.lblSales.Text = "$0000";
            // 
            // la
            // 
            this.la.AutoSize = true;
            this.la.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.la.ForeColor = System.Drawing.Color.White;
            this.la.Location = new System.Drawing.Point(17, 12);
            this.la.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.la.Name = "la";
            this.la.Size = new System.Drawing.Size(73, 30);
            this.la.TabIndex = 0;
            this.la.Text = "Sales";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Orchid;
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.lblAverageperweek);
            this.panel2.Location = new System.Drawing.Point(1041, 266);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(333, 84);
            this.panel2.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(5, 52);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(194, 21);
            this.label9.TabIndex = 0;
            this.label9.Text = "Average Weekly Sales";
            // 
            // lblAverageperweek
            // 
            this.lblAverageperweek.AutoSize = true;
            this.lblAverageperweek.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold);
            this.lblAverageperweek.ForeColor = System.Drawing.Color.White;
            this.lblAverageperweek.Location = new System.Drawing.Point(4, 10);
            this.lblAverageperweek.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAverageperweek.Name = "lblAverageperweek";
            this.lblAverageperweek.Size = new System.Drawing.Size(152, 37);
            this.lblAverageperweek.TabIndex = 1;
            this.lblAverageperweek.Text = "$1,000,00";
            // 
            // lblPorfit
            // 
            this.lblPorfit.AutoSize = true;
            this.lblPorfit.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold);
            this.lblPorfit.ForeColor = System.Drawing.Color.White;
            this.lblPorfit.Location = new System.Drawing.Point(16, 48);
            this.lblPorfit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPorfit.Name = "lblPorfit";
            this.lblPorfit.Size = new System.Drawing.Size(102, 37);
            this.lblPorfit.TabIndex = 1;
            this.lblPorfit.Text = "$0000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(16, 11);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(358, 74);
            this.label4.TabIndex = 0;
            this.label4.Text = "Dashboard";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Plum;
            this.panel3.Controls.Add(this.lblPercent);
            this.panel3.Controls.Add(this.lblDailySales);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.lblText);
            this.panel3.Location = new System.Drawing.Point(1041, 86);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(333, 172);
            this.panel3.TabIndex = 2;
            // 
            // lblPercent
            // 
            this.lblPercent.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold);
            this.lblPercent.ForeColor = System.Drawing.Color.White;
            this.lblPercent.Location = new System.Drawing.Point(11, 39);
            this.lblPercent.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPercent.Name = "lblPercent";
            this.lblPercent.Size = new System.Drawing.Size(303, 34);
            this.lblPercent.TabIndex = 1;
            this.lblPercent.Text = "100%";
            this.lblPercent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblDailySales
            // 
            this.lblDailySales.AutoSize = true;
            this.lblDailySales.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold);
            this.lblDailySales.ForeColor = System.Drawing.Color.White;
            this.lblDailySales.Location = new System.Drawing.Point(11, 73);
            this.lblDailySales.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDailySales.Name = "lblDailySales";
            this.lblDailySales.Size = new System.Drawing.Size(85, 37);
            this.lblDailySales.TabIndex = 1;
            this.lblDailySales.Text = "0000";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(12, 114);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(197, 42);
            this.label7.TabIndex = 0;
            this.label7.Text = "Daily Sales Compared \r\nto Yesterday";
            // 
            // lblText
            // 
            this.lblText.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblText.ForeColor = System.Drawing.Color.White;
            this.lblText.Location = new System.Drawing.Point(11, 12);
            this.lblText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblText.Name = "lblText";
            this.lblText.Size = new System.Drawing.Size(303, 27);
            this.lblText.TabIndex = 0;
            this.lblText.Text = "Increase up to";
            this.lblText.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Violet;
            this.panel4.Controls.Add(this.lblPorfit);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Location = new System.Drawing.Point(16, 201);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(347, 110);
            this.panel4.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(17, 16);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 30);
            this.label6.TabIndex = 0;
            this.label6.Text = "Profit";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1392, 628);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.chrtPie);
            this.Controls.Add(this.chrtBarChart);
            this.Controls.Add(this.chrtSpline);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chrtSpline)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chrtPie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chrtBarChart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chrtSpline;
        private System.Windows.Forms.DataVisualization.Charting.Chart chrtPie;
        private System.Windows.Forms.DataVisualization.Charting.Chart chrtBarChart;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSales;
        private System.Windows.Forms.Label la;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblPorfit;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblDailySales;
        private System.Windows.Forms.Label lblText;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblAverageperweek;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblPercent;
        private System.Windows.Forms.Label label7;
    }
}

