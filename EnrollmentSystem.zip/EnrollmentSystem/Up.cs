﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class Up : Form
    {
        private Form2 home1;
        public Up(Form2 home)
        {
            InitializeComponent();
            home1 = home;
            
        }

        private void Up_Load(object sender, EventArgs e)
        {
            textBox1.Text = Form2.id;
            update();
        }

        private void update()
        {
            
            try
            {
                fn.sql = "SELECT id_stud, std_name, std_mname, std_lname, std_bday, std_bplace, std_status, std_gender FROM tbl_student WHERE id_stud = '" + textBox1.Text + "'";
                fn.connDB();
                SqlCommand query = new SqlCommand(fn.sql, fn.conn);
                SqlDataReader row = query.ExecuteReader();
                if (row.Read())
                {
                    //Data from database to textbox value
                    textBox3.Text = row["std_name"].ToString();
                    textBox4.Text = row["std_mname"].ToString();
                    textBox5.Text = row["std_lname"].ToString();
                    comboBox1.Text = row["std_gender"].ToString();
                    textBox8.Text = row["std_status"].ToString();
                    dateTimePicker1.Text = row["std_bday"].ToString();
                    textBox6.Text = row["std_bplace"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
          
            try
            {
                fn.sql = "UPDATE tbl_student SET std_name = '" + this.textBox3.Text + "', std_mname = '" + this.textBox4.Text + " ', std_lname = '" + this.textBox5.Text + "',std_bday'" + this.dateTimePicker1.Text + "' std_bplace = '" + this.textBox6.Text + "', std_status= '" + this.textBox8.Text + "', std_gender = '" + this.comboBox1.Text + "' WHERE id_stud = '" + this.textBox1.Text + "'";
                fn.connDB();
                SqlCommand query = new SqlCommand(fn.sql, fn.conn);
                SqlDataReader row = query.ExecuteReader();

                home1.student_list();


              
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                fn.sql = "INSERT INTO  tbl_student (id_stud, std_name,std_mname,std_lname, std_bday,std_bplace, std_status, std_gender ) VALUES ('"+this.textBox1.Text+"','" + this.textBox3.Text + "','" + this.textBox4.Text + "','" + this.textBox5.Text + "','"+this.dateTimePicker1.Text+"','" + this.textBox6.Text + "','" + this.textBox8.Text + "','" + this.comboBox1.Text + "')";
                fn.connDB();
                SqlCommand query = new SqlCommand(fn.sql, fn.conn);
                SqlDataReader row = query.ExecuteReader();

                home1.student_list();



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
