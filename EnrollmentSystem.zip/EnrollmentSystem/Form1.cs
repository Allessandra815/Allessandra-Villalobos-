﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                label3.Visible = true;
            }
            if (textBox2.Text == "")
            {
                label4.Visible = true;
            }

            fn.sql = "SELECT * FROM tbl_user WHERE user_email = '" + this.textBox1.Text + "'";


            try
            {
                fn.connDB();
                SqlCommand query = new SqlCommand(fn.sql, fn.conn);
                SqlDataReader row = query.ExecuteReader();

                if (!row.Read())
                {
                   textBox1.Focus();
                    label3.Visible = true;
                    label3.Text = "Email Address doesn't exists.";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            fn.sql = "SELECT * FROM tbl_user WHERE user_password = '" + this.textBox2.Text + "'";


            try
            {
                fn.connDB();
                SqlCommand query = new SqlCommand(fn.sql, fn.conn);
                SqlDataReader row = query.ExecuteReader();

                if (!row.Read())
                {
                   textBox2.Focus();
                    label4.Visible = true;
                    label4.Text = "Password incorrect.Please try again";
                }

                else
                {
                    Form2 home = new Form2();
                    home.Show();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
