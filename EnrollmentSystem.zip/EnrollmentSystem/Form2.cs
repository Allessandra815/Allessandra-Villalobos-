﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        public static String id;

        private void Form2_Load(object sender, EventArgs e)
        {
            student_list();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void student_list()
        {
            try
            {
                fn.sql = "SELECT id_stud AS [Student ID], std_name AS [Name],std_mname AS [Middle Name], std_lname AS [Last Name], std_bday AS [Birthday], std_bplace AS [Birth Place], std_status AS [Status], std_gender AS [Gender] FROM tbl_student";
                fn.connDB();
                fn.da = new System.Data.SqlClient.SqlDataAdapter(fn.sql, fn.conn);
                fn.dt = new DataTable();
                fn.da.Fill(fn.dt);
                dataGridView1.DataSource = fn.dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txt_id_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                try
                {
                    fn.sql = "SELECT id_stud AS [Student ID], std_name AS [Name],std_mname AS [Middle Name], std_lname AS [Last Name], std_bday AS [Birthday], std_bplace AS [Birth Place], std_status AS [Status], std_gender AS [Gender] FROM tbl_student";
                    fn.connDB();
                    fn.da = new System.Data.SqlClient.SqlDataAdapter(fn.sql, fn.conn);
                    fn.dt = new DataTable();
                    fn.da.Fill(fn.dt);
                    dataGridView1.DataSource = fn.dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                try
                {
                    fn.sql = "SELECT id_stud AS [Student ID], std_name AS [Name],std_mname AS [Middle Name], std_lname AS [Last Name], std_bday AS [Birthday], std_bplace AS [Birth Place], std_status AS [Status], std_gender AS [Gender] FROM tbl_student WHERE id_stud LIKE '" + this.textBox1.Text + "%' OR std_name LIKE '" + this.textBox1.Text + "%' OR std_lname LIKE '" + this.textBox1.Text + "%'";
                    fn.connDB();
                    fn.da = new System.Data.SqlClient.SqlDataAdapter(fn.sql, fn.conn);
                    fn.dt = new DataTable();
                    fn.da.Fill(fn.dt);
                    dataGridView1.DataSource = fn.dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }
        private void info()
        {
            try
            {
                fn.sql = "SELECT id_stud, std_name, std_mname, std_lname, std_bday, std_bplace, std_status, std_gender FROM tbl_student WHERE id_stud = '" + id_num.Text + "'";
                fn.connDB();
                SqlCommand query = new SqlCommand(fn.sql, fn.conn);
                SqlDataReader row = query.ExecuteReader();
                if (row.Read())
                {
                    //Data from database to textbox value
                    label7.Text = row["std_lname"].ToString() + ", \n" + row["std_name"].ToString() + " " + row["std_mname"].ToString();
                    label3.Text = row["std_gender"].ToString();
                    label4.Text = row["std_status"].ToString();
                    label5.Text = row["std_bday"].ToString();
                    label6.Text = row["std_bplace"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            //fn.Rows.Clear();

            try
            {
                DataGridView dgv = sender as DataGridView;
                if (dgv != null && dgv.SelectedRows.Count > 0)
                {
                    DataGridViewRow row1 = dgv.SelectedRows[0];
                    if (row1 != null)
                    id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                    id_num.Text = id;

                    info();
                    
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (id != "")
            {
                Up update = new Up(this);
                update.Show();

            }
            else {
                MessageBox.Show("Please select");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Up add= new Up(this);
            id = "";
            add.Show();
        }
    }
}
